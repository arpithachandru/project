package com.spring.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.dto.AdminDTO;
import com.spring.dto.CandidateDTO;
import com.spring.dto.UserDTO;

@Repository
public class AdminDAO {
	@Autowired
	private SessionFactory factory;

	/*public Integer saveAdmin(AdminDTO adminDTO) {
		Transaction transaction = null;
		Integer numberOfUserRegistered = null;
		try (Session session = factory.openSession())
		{
			transaction = session.beginTransaction();
			numberOfUserRegistered = (Integer) session.save(adminDTO);
			transaction.commit();
			session.close(); 
		} catch (HibernateException e) {
			e.printStackTrace();

		}
		return numberOfUserRegistered;
	}
	*/
	public AdminDTO adminlog(String email, String password) 
	{
		AdminDTO adminDTO = null;
		String hql = "select admin from AdminDTO admin where admin.email=:name1 and admin.password=:name2";
		try (Session session = factory.openSession()) {
			Query query = session.createQuery(hql);
			query.setParameter("name1", email);
			query.setParameter("name2", password);
		adminDTO = (AdminDTO) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return adminDTO;
	}
	
}
