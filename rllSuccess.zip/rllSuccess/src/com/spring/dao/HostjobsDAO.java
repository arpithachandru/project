package com.spring.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.dto.CandidateDTO;
import com.spring.dto.HostJobDTO;
import com.spring.dto.UserDTO;

@Repository
public class HostjobsDAO {

	@Autowired
	private SessionFactory factory;

	public Integer saveJob(HostJobDTO hostJobDTO) {
		Transaction transaction = null;
		Integer numberOfUserRegistered = null;
		try (Session session = factory.openSession())
		{
			transaction = session.beginTransaction();
			numberOfUserRegistered = (Integer) session.save(hostJobDTO);
			transaction.commit();
			session.close(); 
		} catch (HibernateException e) {
			e.printStackTrace();

		}
		return numberOfUserRegistered;
	}

}
