package com.spring.dto;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

	@Entity
	@Table(name = "candidate")
	public class CandidateDTO implements Serializable {
		@Id
		@GenericGenerator(name = "auto", strategy = "increment")
		@GeneratedValue(generator = "auto")
		@Column(name = "cid")
		private int cid;
		@Column(name = "name")
		private String name;
		@Column(name = "email")
		private String email;
		@Column(name = "address")
		private String address;
		@Column(name = "phone_no")
		private String phone_no;
		@Column(name = "password")
		private String password;
		@Column(name = "dob")
		private Date dob;
		@Column(name = "ssc_per")
		private String ssc_per;
		@Column(name = "hsc_per")
		private String hsc_per;
		@Column(name = "pg_per")
		private String pg_per;
		@Column(name = "pg_yop")
		private int pg_yop;
		@Column(name = "pg_stream")
		private String pg_stream;
		@Column(name = "ug_per")
		private String ug_per;
		@Column(name = "ug_yop")
		private int ug_yop;
		@Column(name = "ug_stream")
		private String ug_stream;
		@Column(name = "confirm_password")
		private String confirm_password;
		@Column(name = "securedquestion")
		private String securedquestion;
		@Column(name = "securedanswer")
		private String securedanswer;
		
		
	

		public CandidateDTO() {
			System.out.println(this.getClass().getSimpleName() + " object created");
		}


		public int getCid() {
			return cid;
		}


		public void setCid(int cid) {
			this.cid = cid;
		}


		public String getName() {
			return name;
		}


		public void setName(String name) {
			this.name = name;
		}


		public String getEmail() {
			return email;
		}


		public void setEmail(String email) {
			this.email = email;
		}


		public String getAddress() {
			return address;
		}


		public void setAddress(String address) {
			this.address = address;
		}


		public String getPhone_no() {
			return phone_no;
		}


		public void setPhone_no(String phone_no) {
			this.phone_no = phone_no;
		}


		public String getPassword() {
			return password;
		}


		public void setPassword(String password) {
			this.password = password;
		}


		public Date getDob() {
			return dob;
		}


		public void setDob(Date dob) {
			this.dob = dob;
		}


		public String getSsc_per() {
			return ssc_per;
		}


		public void setSsc_per(String ssc_per) {
			this.ssc_per = ssc_per;
		}


		public String getHsc_per() {
			return hsc_per;
		}


		public void setHsc_per(String hsc_per) {
			this.hsc_per = hsc_per;
		}


		public String getPg_per() {
			return pg_per;
		}


		public void setPg_per(String pg_per) {
			this.pg_per = pg_per;
		}


		public int getPg_yop() {
			return pg_yop;
		}


		public void setPg_yop(int pg_yop) {
			this.pg_yop = pg_yop;
		}


		public String getPg_stream() {
			return pg_stream;
		}


		public void setPg_stream(String pg_stream) {
			this.pg_stream = pg_stream;
		}


		public String getUg_per() {
			return ug_per;
		}


		public void setUg_per(String ug_per) {
			this.ug_per = ug_per;
		}


		public int getUg_yop() {
			return ug_yop;
		}


		public void setUg_yop(int ug_yop) {
			this.ug_yop = ug_yop;
		}


		public String getUg_stream() {
			return ug_stream;
		}


		public void setUg_stream(String ug_stream) {
			this.ug_stream = ug_stream;
		}


		public String getConfirm_password() {
			return confirm_password;
		}


		public void setConfirm_password(String confirm_password) {
			this.confirm_password = confirm_password;
		}


		public String getSecuredquestion() {
			return securedquestion;
		}


		public void setSecuredquestion(String securedquestion) {
			this.securedquestion = securedquestion;
		}


		public String getSecuredanswer() {
			return securedanswer;
		}


		public void setSecuredanswer(String securedanswer) {
			this.securedanswer = securedanswer;
		}



		
	
	}


