package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.CandidateDAO;
import com.spring.dao.HostjobsDAO;
import com.spring.dao.RegistrationDAO;
import com.spring.dto.CandidateDTO;
import com.spring.dto.HostJobDTO;
import com.spring.dto.UserDTO;
@Service
public class HostjobService {
	@Autowired
	private HostjobsDAO hostjobsDAO;

	public boolean jobregister(HostJobDTO hostJobDTO) {
		Integer saveJob = hostjobsDAO.saveJob(hostJobDTO);
		if (saveJob != null && saveJob > 0) {
			return true;
		} else {
			return false;
		}
	}
}
