
$(document).ready(function(){
$('form[id="form_val"]').validate({
rules:{
name: "required",
password: {
required: true,
minlength: 6
}
},
messages:{
name:"Please give the name",
password:{
required: "Please enter the password",
minlength:"Provide atleast 6 characters"
}
},
submitHandler:function(form){
form.submit();
}
});
});

