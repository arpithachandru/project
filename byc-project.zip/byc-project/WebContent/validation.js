$(function(){

$('form[id="form"]').validate({

rules:{

  name: "required",
  email: "required",
  number: "required",
  password: "required",
  dl: "required",
  from: "required",
  to: "required",
  secquestion: "required",

 email: {
                
                required: true,
                email: true
            },

 secquestion: {
                 required: true
 },

  email_login: {
                
                required: true,
            },

 number: {
                
                required: true,
                number: true,
                minlength: 10,
                maxlength: 10
 },

password:{
           
            required: true,
            minlength:5,
            maxlength:16

},

confirm_password:{
            required: true,
            minlength:5,
            maxlength:16
},

loginPassword:{
           
            required: true
},

 email_password: {
                
                required: true,
            },

npassword:{
           
            required: true,
            minlength: 5,
            maxlength: 16

},

dl:{
          
          required : true,
          maxlength : 10
},

name: {

         required : true,
        // lettersonly : true,
         minlength : 3,
        maxlength: 20
  },

carNumber: {
          required : true,
          minlength : 10,
          maxlength: 10
  },

carName: {
          required : true,
          minlength : 3,
          maxlength: 20
},

carType: {
          required : true,
          minlength : 3,
          maxlength: 20
},

carImage: {
          required : true
},

from: {
        required : true,
},

to:{
        required:true,
},

radiobutton:{
  required: true
},

secanswer:{
	required: true
},

ddown:{
  required: true
  },
},
    submitHandler:function(form){
    form.submit();
      }
  });
});
