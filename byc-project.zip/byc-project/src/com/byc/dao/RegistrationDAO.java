package com.byc.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.byc.dto.RegistrationDTO;

@Repository
public class RegistrationDAO {

	@Autowired
	private SessionFactory factory;

	public Integer saveUser(RegistrationDTO registrationDTO) {
		Transaction transaction = null;
		Integer userRegistered = null;
		try (Session session = factory.openSession()) {
			transaction = session.beginTransaction();
			userRegistered = (Integer) session.save(registrationDTO);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return userRegistered;
	}

	public RegistrationDTO loginUser(String email, String password) {
		RegistrationDTO registrationDTO = null;
		String hql = "select customer from RegistrationDTO customer where customer.userEmail=:name1 and customer.userPassword=:name2";
		try (Session session = factory.openSession()) {
			Query query = session.createQuery(hql);
			query.setParameter("name1", email);
			query.setParameter("name2", password);
			registrationDTO = (RegistrationDTO) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return registrationDTO;
	}

}
