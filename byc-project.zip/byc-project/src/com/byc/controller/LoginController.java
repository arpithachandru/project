package com.byc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.byc.dto.RegistrationDTO;
import com.byc.service.RegistrationService;

@Controller
public class LoginController {

	@Autowired
	private RegistrationService registrationService;

	@PostMapping("/login.do")
	public ModelAndView loginUser(@RequestParam String email_login, @RequestParam String loginPassword) {

		RegistrationDTO registrationDTO = new RegistrationDTO();

		registrationDTO.setUserEmail(email_login);
		registrationDTO.setUserPassword(loginPassword);

		boolean present = registrationService.loginCustomer(registrationDTO);
		if (present) {
			return new ModelAndView("customerHome.html");
		} else {
			return new ModelAndView("failLogin.html");
		}
	}
}
