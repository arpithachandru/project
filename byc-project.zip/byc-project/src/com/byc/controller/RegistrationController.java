package com.byc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.byc.dto.RegistrationDTO;
import com.byc.service.RegistrationService;

@Controller
public class RegistrationController {

	@Autowired
	private RegistrationService registrationService;

	@PostMapping("/registrationDone.do")
	public ModelAndView register(@RequestParam String name, @RequestParam String email, @RequestParam Long number,
			@RequestParam String password, @RequestParam String dl, @RequestParam String secquestion,
			@RequestParam String secanswer) {

		RegistrationDTO registrationDTO = new RegistrationDTO();

		Integer dlBYC = Integer.parseInt(dl);

		registrationDTO.setUserName(name);
		registrationDTO.setDrivingLicense(dlBYC);
		registrationDTO.setUserEmail(email);
		registrationDTO.setUserMobile(number);
		registrationDTO.setUserPassword(password);
		registrationDTO.setSecurityQuestion(secquestion);
		registrationDTO.setSecurityAnswer(secanswer);

		boolean register = registrationService.register(registrationDTO);

		if (register) {
			return new ModelAndView("registerSuccess.html");
		} else {
			return new ModelAndView("failRegister.html");
		}
	}
}
