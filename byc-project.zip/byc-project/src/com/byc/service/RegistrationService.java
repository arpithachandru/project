package com.byc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.byc.dao.RegistrationDAO;
import com.byc.dto.RegistrationDTO;

@Service
public class RegistrationService {

	@Autowired
	private RegistrationDAO registrationDAO;

	public boolean register(RegistrationDTO registrationDTO) {
		Integer saveUser = registrationDAO.saveUser(registrationDTO);
		if (saveUser != null && saveUser > 0) {
			return true;
		} else {
			return false;
		}
	}

	public boolean loginCustomer(RegistrationDTO dto) {
		String email = dto.getUserEmail();
		String password = dto.getUserPassword();
		RegistrationDTO loginUser = registrationDAO.loginUser(email, password);
		if (loginUser != null) {
			return true;
		} else {
			return false;
		}
	}

}
