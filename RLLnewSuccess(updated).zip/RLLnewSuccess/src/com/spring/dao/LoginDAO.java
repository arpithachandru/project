package com.spring.dao;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.dto.CandidateDTO;
import com.spring.dto.UserDTO;
@Repository
public class LoginDAO {
	@Autowired
	private SessionFactory factory;

	public Integer saveCandidate(CandidateDTO candidateDTO) {
		Transaction transaction = null;
		Integer numberOfUserRegistered = null;
		try (Session session = factory.openSession())
		{
			transaction = session.beginTransaction();
			numberOfUserRegistered = (Integer) session.save(candidateDTO);
			transaction.commit();
			session.close(); 
		} catch (HibernateException e) {
			e.printStackTrace();

		}
		return numberOfUserRegistered;
	}
	
	//candidate login
	public CandidateDTO loginUser(String email, String password) 
	{
		CandidateDTO candidateDTO = null;
		String hql = "select candidate from CandidateDTO candidate where candidate.email=:name1 and candidate.password=:name2";
		try (Session session = factory.openSession()) {
			Query query = session.createQuery(hql);
			query.setParameter("name1", email);
			query.setParameter("name2", password);
			candidateDTO = (CandidateDTO) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return candidateDTO;
	}
	
	//Company login
	
	public UserDTO companylog(String email, String password) 
	{
		UserDTO userDTO = null;
		String hql = "select company from UserDTO company where company.email=:name1 and company.password=:name2";
		try (Session session = factory.openSession()) {
			Query query = session.createQuery(hql);
			query.setParameter("name1", email);
			query.setParameter("name2", password);
		userDTO = (UserDTO) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return userDTO;
	}
	
	 //security
	
	
	
	
	
	
}
