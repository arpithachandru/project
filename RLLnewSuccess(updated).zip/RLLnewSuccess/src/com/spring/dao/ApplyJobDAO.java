package com.spring.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.dto.ApplyJobDTO;

@Repository
public class ApplyJobDAO {
	@Autowired
	private SessionFactory factory;

	public Integer saveJob(ApplyJobDTO applyJobDTO) {
		Transaction transaction = null;
		Integer numberOfUserRegistered = null;
		try (Session session = factory.openSession())
		{
			transaction = session.beginTransaction();
			numberOfUserRegistered = (Integer) session.save(applyJobDTO);
			transaction.commit();
			session.close(); 
		} catch (HibernateException e) {
			e.printStackTrace();

		}
		return numberOfUserRegistered;
	}
}
