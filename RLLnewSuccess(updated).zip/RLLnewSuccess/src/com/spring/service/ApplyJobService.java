package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.ApplyJobDAO;
import com.spring.dao.HostjobsDAO;
import com.spring.dto.ApplyJobDTO;
import com.spring.dto.HostJobDTO;

@Service
public class ApplyJobService {
	@Autowired
	private ApplyJobDAO applyJobDAO;
	
	public boolean jobApply(ApplyJobDTO applyJobDTO) {
		Integer saveJob = applyJobDAO.saveJob(applyJobDTO);
		if (saveJob != null && saveJob > 0) {
			return true;
		} else {
			return false;
		}
	}
}
