$(document).ready(function(){

$('form[id="form_val"]').validate({
rules:{

name: "required",
password: {
required: true,
minlength:6



},
confirm_password:{
required: true,
equalTo: "#cpassword"
},
dob:"required",

phone_no:{
required:true,
minlength:10,
maxlength:10,
},

email:{
required:true,
email:true,
},


address:"required",
ssc_per:"required",
hsc_per: "required",
ug_per: "required",
ug_yop: "required",
ug_stream: "required",

securedquestion: "required",
securedanswer: "required"
},
messages:{
name:"Name is required",

password:{
required: "Enter the password",
	minLength: "minimum length should be 6"

},
confirm_password:{
required:"Enter confirm password",
equalTo:"Passwords does not match",
},
dob:{
	required:"Enter date of birth"
},
phone_no:{
required:" Enter contact no",
minlength:"Contact no must be 10 digit",
maxlength:"Contact no must be 10 digit"
},
email:{
required:"Enter valid Email"
},
address:{
required:" Enter address"
},

ssc_per:
{
required:"Enter  percentage"
},
hsc_per:{
required:"Enter  percentage"
},

ug_per:{
required:"Enter UG percentage"
},
ug_yop:{
required:"Enter year of passing"
},
ug_stream:{
required:"Enter UG branch"
},

securedquestion:{
required:"Please select question"
},
securedanswer:{
required:"Please provide answer"
}
},

submitHandler:function(form){
form.submit();
}
});
}); 