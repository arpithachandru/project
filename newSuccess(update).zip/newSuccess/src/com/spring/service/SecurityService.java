package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.SecurityDAO;
import com.spring.dto.CandidateDTO;
import com.spring.dto.UserDTO;
@Service
public class SecurityService {
	
	@Autowired
	private SecurityDAO securityDAO;

	public boolean candidatelogin(CandidateDTO candidateDTO) {
		Integer saveCandidate = securityDAO.saveCandidate(candidateDTO);
		if (saveCandidate != null && saveCandidate > 0) {
			return true;
		} else {
			return false;
		}
	}
	// candidate security
		public boolean security(CandidateDTO candidateDTO) {
			String securedquestion = candidateDTO.getSecuredquestion();
			String securedanswer = candidateDTO.getSecuredanswer();
		CandidateDTO secure = securityDAO.securelog(securedquestion, securedanswer);
			if (secure != null) {
				return true;
			} else {
				return false;
			}
		}
		// company security
				public boolean securityans(UserDTO userDTO) {
					String securedquestion = userDTO.getSecuredquestion();
					String securedanswer = userDTO.getSecuredanswer();
					UserDTO secure = securityDAO.securecompany(securedquestion, securedanswer);
					if (secure != null) {
						return true;
					} else {
						return false;
					}
				}
		// candidate reset
				
				public boolean passwordReset(CandidateDTO candidateDTO) {
					String email = candidateDTO.getEmail();
					String password = candidateDTO.getPassword();
					String confirm_password = candidateDTO.getConfirm_password();
					
					int passwordUpdate = securityDAO.updatePass(email,password, confirm_password);
					if(passwordUpdate>0 ) {
						return true;
					}else {
						return false;
					}
				}
// company reset
				
				public boolean companyReset(UserDTO userDTO) {
					String email = userDTO.getEmail();
					String password = userDTO.getPassword();
					String confirmpassword = userDTO.getConfirmpassword();
					
					int passwordUpdate = securityDAO.companyPass(email,password, confirmpassword);
					if(passwordUpdate>0 ) {
						return true;
					}else {
						return false;
					}
				}
}
