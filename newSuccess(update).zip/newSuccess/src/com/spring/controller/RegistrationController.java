package com.spring.controller;

import java.util.Date;

import javax.persistence.Column;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.dto.AdminDTO;
import com.spring.dto.CandidateDTO;
import com.spring.dto.HostJobDTO;
import com.spring.dto.UserDTO;
import com.spring.service.AdminService;
import com.spring.service.CandidateRegService;
import com.spring.service.HostjobService;
import com.spring.service.LoginService;
import com.spring.service.RegistrationService;
import com.spring.service.SecurityService;

@Controller
public class RegistrationController {

	@Autowired
	private RegistrationService registrationService;

	@Autowired
	private SecurityService securityService;
	@Autowired
	private CandidateRegService candidateRegService;
	
	@Autowired
	private AdminService adminService;

	@Autowired
	private HostjobService hostjobService;
	
	@Autowired
	private LoginService loginService;
	
	
	@PostMapping("/login.do")
	public ModelAndView registerCompany(@RequestParam String name, @RequestParam String address,
			@RequestParam String description,@RequestParam String email,@RequestParam String website,@RequestParam String password,@RequestParam long phone_no,@RequestParam String confirmpassword,@RequestParam String securedquestion,@RequestParam String securedanswer) {
		UserDTO userDTO = new UserDTO();
		userDTO.setName(name);
		userDTO.setAddress(address);
		userDTO.setDescription(description);
		userDTO.setEmail(email);
		userDTO.setWebsite(website);
		userDTO.setPassword(password);
		userDTO.setAddress(address);
		userDTO.setPhone_no(phone_no);
		userDTO.setConfirmpassword(confirmpassword);
		userDTO.setSecuredquestion(securedquestion);
	userDTO.setSecuredanswer(securedanswer);
		
	
		boolean register = registrationService.register(userDTO);

		if (register) 
		{
			return new ModelAndView("companylogin.html");
		} 
		else 
		{
			return new ModelAndView("failure.html");
		}
		
	}
	
	
	
	
	@PostMapping("/candidateregister.do")
	public ModelAndView registerCandidate(@RequestParam String name, @RequestParam String email,
			@RequestParam String address,@RequestParam String phone_no,@RequestParam String password,@RequestParam String dob,@RequestParam String ssc_per,@RequestParam String hsc_per,@RequestParam String pg_per,@RequestParam int pg_yop,@RequestParam String pg_stream,@RequestParam String ug_per,@RequestParam int ug_yop,@RequestParam String ug_stream,@RequestParam String confirm_password,@RequestParam String securedquestion,@RequestParam String securedanswer) {
		CandidateDTO candidateDTO = new CandidateDTO();
		candidateDTO.setName(name);
		candidateDTO.setEmail(email);
		candidateDTO.setAddress(address);
		candidateDTO.setPhone_no(phone_no);
		candidateDTO.setPassword(password);
		candidateDTO.setDob(dob);
		candidateDTO.setSsc_per(ssc_per);
		
		candidateDTO.setHsc_per(hsc_per);
		
		candidateDTO.setPg_per(pg_per);
		candidateDTO.setPg_yop(pg_yop);
		candidateDTO.setPg_stream(pg_stream);
		candidateDTO.setUg_per(ug_per);
		candidateDTO.setUg_yop(ug_yop);
		candidateDTO.setUg_stream(ug_stream);
		candidateDTO.setConfirm_password(confirm_password);
		candidateDTO.setSecuredquestion(securedquestion);
		candidateDTO.setSecuredanswer(securedanswer);
		
	
		boolean register = candidateRegService.candregister(candidateDTO);

		if (register) {
			return new ModelAndView("candidatelogin.html");
		} else {
			return new ModelAndView("failure.html");
		}
}
	
	@PostMapping("/login1.do")
	public ModelAndView loginUser(@RequestParam String email, @RequestParam String password) {

		CandidateDTO candidateDTO = new CandidateDTO();

		candidateDTO.setEmail(email);
		candidateDTO.setPassword(password);
		

		boolean present = loginService.loginCandidate(candidateDTO);
		if (present) {
			return new ModelAndView("my-profile.html");
		} else {
			return new ModelAndView("failure.html");
		}
	}
	//company
	
	
	@PostMapping("/login2.do")
	public ModelAndView loginCompanyreg(@RequestParam String email, @RequestParam String password) {

		UserDTO userDTO = new UserDTO();

		userDTO.setEmail(email);
		userDTO.setPassword(password);

		boolean present = loginService.loginCompany(userDTO);
		if (present) {
			return new ModelAndView("companyportal.html");
		} else {
			return new ModelAndView("failure.html");
		}
	}
	
	@PostMapping("/adminlogin.do")
	public ModelAndView loginAdminreg(@RequestParam String email, @RequestParam String password) {

		AdminDTO adminDTO = new AdminDTO();

		adminDTO.setEmail(email);
		adminDTO.setPassword(password);

		boolean present = adminService.loginAdmin(adminDTO);
		if (present) {
			return new ModelAndView("AdminHome.html");
		} else {
			return new ModelAndView("failure.html");
		}
	}
	
	//security candidate

	@PostMapping("/security.do")
	public ModelAndView securequestion(@RequestParam String securedquestion, @RequestParam String securedanswer) {

		CandidateDTO candidateDTO = new CandidateDTO();

		candidateDTO.setSecuredquestion(securedquestion);
		candidateDTO.setSecuredanswer(securedanswer);

		boolean present = securityService.security(candidateDTO);
		if (present) {
			return new ModelAndView("reset.html");
		} else {
			return new ModelAndView("failure.html");
		}
	}
	
	//security company

		@PostMapping("/security2.do")
		public ModelAndView secureanswer(@RequestParam String securedquestion, @RequestParam String securedanswer) {

			UserDTO userDTO = new UserDTO();

			userDTO.setSecuredquestion(securedquestion);
			userDTO.setSecuredanswer(securedanswer);

			boolean present = securityService.securityans(userDTO);
			if (present) {
				return new ModelAndView("reset.html");
			} else {
				return new ModelAndView("failure.html");
			}
		}
		
		
		//candidate password update
		
		
		
		@PostMapping("/reset.do")
		public ModelAndView resetPassword(@RequestParam String email,@RequestParam String password, @RequestParam String confirmpassword) {
			
			CandidateDTO  candidateDTO= new CandidateDTO();
			candidateDTO.setEmail(email);
			candidateDTO.setPassword(password);
			candidateDTO.setConfirm_password(confirmpassword);
			
			boolean update = securityService.passwordReset(candidateDTO);
			if(update) {
				return new ModelAndView("candidatelogin.html");
			}else {
				return new ModelAndView("failure.html");
			}
		}
		
		@PostMapping("/companyreset.do")
		public ModelAndView companyPassword(@RequestParam String email,@RequestParam String password, @RequestParam String confirmpassword) {
			
			UserDTO  userDTO= new UserDTO();
			userDTO.setEmail(email);
			userDTO.setPassword(password);
			userDTO.setConfirmpassword(confirmpassword);
			
			boolean update = securityService.companyReset(userDTO);
			if(update) {
				return new ModelAndView("companylogin.html");
			}else {
				return new ModelAndView("failure.html");
			}
		}
	}
		
		
