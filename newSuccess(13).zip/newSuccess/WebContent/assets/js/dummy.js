function la(src)
{
	window.location = src;
}