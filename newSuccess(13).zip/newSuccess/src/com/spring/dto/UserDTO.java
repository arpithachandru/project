package com.spring.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "company_gen_details")
public class UserDTO implements Serializable {
	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "cmid")
	private int cmid;
	@Column(name = "name")
	private String name;
	@Column(name = "address")
	private String address;
	@Column(name = "description")
	private String description;
	@Column(name = "email")
	private String email;
	@Column(name = "website")
	private String website;
	
	


	@Column(name = "password")
	private String password;
	@Column(name = "phone_no")
	private long phone_no;
	
	@Column(name = "confirmpassword")
	private String confirmpassword;
	@Column(name = "securedquestion")
	private String securedquestion;
	@Column(name = "securedanswer")
	private String securedanswer;
	


	



	public String getSecuredquestion() {
		return securedquestion;
	}



	public void setSecuredquestion(String securedquestion) {
		this.securedquestion = securedquestion;
	}



	public String getSecuredanswer() {
		return securedanswer;
	}



	public void setSecuredanswer(String securedanswer) {
		this.securedanswer = securedanswer;
	}



	public UserDTO() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}



	public int getCmid() {
		return cmid;
	}



	public void setCmid(int cmid) {
		this.cmid = cmid;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public long getPhone_no() {
		return phone_no;
	}



	public void setPhone_no(long phone_no) {
		this.phone_no = phone_no;
	}
	public String getConfirmpassword() {
		return confirmpassword;
	}
	public String getWebsite() {
		return website;
	}



	public void setWebsite(String website) {
		this.website = website;
	}


	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}



		
}
