package com.spring.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.dto.CandidateDTO;
import com.spring.dto.UserDTO;
@Repository
public class SecurityDAO {
	@Autowired
	private SessionFactory factory;

	public Integer saveCandidate(CandidateDTO candidateDTO) {
		Transaction transaction = null;
		Integer numberOfUserRegistered = null;
		try (Session session = factory.openSession())
		{
			transaction = session.beginTransaction();
			numberOfUserRegistered = (Integer) session.save(candidateDTO);
			transaction.commit();
			session.close(); 
		} catch (HibernateException e) {
			e.printStackTrace();

		}
		return numberOfUserRegistered;
	}
	
	// candidate reset
	public int securelog(String securedquestion, String securedanswer,String email,String password) 
	{
		int NoOfRecordUpdate = 0;
		Transaction transaction = null;
		String hql = "update CandidateDTO reset set reset.password=:name1  where reset.email=:name3 and reset.securedquestion=:name4 and reset.securedanswer=:name5";
		try (Session session = factory.openSession()) {
			transaction = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setParameter("name1", password);
			
			query.setParameter("name3", email);
			query.setParameter("name4", securedquestion);
			query.setParameter("name5", securedanswer);
			NoOfRecordUpdate = query.executeUpdate();
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		}
		
		return NoOfRecordUpdate;
	}
	// Company reset
	
	public int securecompany(String securedquestion, String securedanswer,String email,String password) 
	{
		int NoOfRecordUpdate = 0;
		Transaction transaction = null;
		String hql = "update UserDTO companyreset set companyreset.password=:name1  where companyreset.email=:name3 and companyreset.securedquestion=:name4 and companyreset.securedanswer=:name5";
		try (Session session = factory.openSession()) {
			transaction = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setParameter("name1", password);
			query.setParameter("name3", email);
			query.setParameter("name4", securedquestion);
			query.setParameter("name5", securedanswer);
			NoOfRecordUpdate = query.executeUpdate();
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		}
		
		return NoOfRecordUpdate;
	}
	
	
	
	
	
}

	
	

