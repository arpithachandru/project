package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.SecurityDAO;
import com.spring.dto.CandidateDTO;
import com.spring.dto.UserDTO;
@Service
public class SecurityService {
	
	@Autowired
	private SecurityDAO securityDAO;

	public boolean candidatelogin(CandidateDTO candidateDTO) {
		Integer saveCandidate = securityDAO.saveCandidate(candidateDTO);
		if (saveCandidate != null && saveCandidate > 0) {
			return true;
		} else {
			return false;
		}
	}
	// candidate security
		public boolean security(CandidateDTO candidateDTO) {
			String securedquestion = candidateDTO.getSecuredquestion();
			String securedanswer = candidateDTO.getSecuredanswer();
			String email = candidateDTO.getEmail();
			String password = candidateDTO.getPassword();
			int secure = securityDAO.securelog(securedquestion, securedanswer,email,password);
			if (secure>0) {
				return true;
			} else {
				return false;
			}
		}
		// company security
				public boolean securityans(UserDTO userDTO) {
					String securedquestion = userDTO.getSecuredquestion();
					String securedanswer = userDTO.getSecuredanswer();
					String email = userDTO.getEmail();
					String password = userDTO.getPassword();
					int secure = securityDAO.securecompany(securedquestion, securedanswer,email,password);
					if (secure>0) {
						return true;
					} else {
						return false;
					}
				}
		

}
