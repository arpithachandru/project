package com.spring.controller;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.dto.AdminDTO;
import com.spring.dto.ApplyJobDTO;
import com.spring.dto.CandidateDTO;
import com.spring.dto.HostJobDTO;
import com.spring.dto.UserDTO;
import com.spring.service.AdminService;
import com.spring.service.ApplyJobService;
import com.spring.service.CandidateRegService;
import com.spring.service.HostjobService;
import com.spring.service.LoginService;
import com.spring.service.RegistrationService;
import com.spring.service.SecurityService;

@Controller
public class RegistrationController {

	@Autowired
	private RegistrationService registrationService;

	@Autowired
	private SecurityService securityService;
	@Autowired
	private CandidateRegService candidateRegService;
	
	@Autowired
	private AdminService adminService;

	@Autowired
	private HostjobService hostjobService;
	
	@Autowired
	private LoginService loginService;
	@Autowired
	private ApplyJobService applyService;
	
	
	
	@PostMapping("/login.do")
	public ModelAndView registerCompany(@RequestParam String name, @RequestParam String address,
			@RequestParam String description,@RequestParam String email,@RequestParam String website,@RequestParam String password,@RequestParam long phone_no,@RequestParam String securedquestion,@RequestParam String securedanswer) {
		UserDTO userDTO = new UserDTO();
		userDTO.setName(name);
		userDTO.setAddress(address);
		userDTO.setDescription(description);
		userDTO.setEmail(email);
		userDTO.setWebsite(website);
		userDTO.setPassword(password);
		userDTO.setAddress(address);
		userDTO.setPhone_no(phone_no);
		//userDTO.setConfirmpassword(confirmpassword);
		userDTO.setSecuredquestion(securedquestion);
	userDTO.setSecuredanswer(securedanswer);
		
	
		boolean register = registrationService.register(userDTO);

		if (register) 
		{
			return new ModelAndView("companylogin.html");
		} 
		else 
		{
			return new ModelAndView("failure.html");
		}
		
	}
	
	
	
	
	@PostMapping("/candidateregister.do")
	public ModelAndView registerCandidate(@RequestParam String name, @RequestParam String email,
			@RequestParam String address,@RequestParam String phone_no,@RequestParam String password,@RequestParam String dob,@RequestParam String ssc_per,@RequestParam String hsc_per,@RequestParam String pg_per,@RequestParam int pg_yop,@RequestParam String pg_stream,@RequestParam String ug_per,@RequestParam int ug_yop,@RequestParam String ug_stream,@RequestParam String securedquestion,@RequestParam String securedanswer) {
		CandidateDTO candidateDTO = new CandidateDTO();
		candidateDTO.setName(name);
		candidateDTO.setEmail(email);
		candidateDTO.setAddress(address);
		candidateDTO.setPhone_no(phone_no);
		candidateDTO.setPassword(password);
		candidateDTO.setDob(dob);
		candidateDTO.setSsc_per(ssc_per);
		
		candidateDTO.setHsc_per(hsc_per);
		
		candidateDTO.setPg_per(pg_per);
		candidateDTO.setPg_yop(pg_yop);
		candidateDTO.setPg_stream(pg_stream);
		candidateDTO.setUg_per(ug_per);
		candidateDTO.setUg_yop(ug_yop);
		candidateDTO.setUg_stream(ug_stream);
		
		candidateDTO.setSecuredquestion(securedquestion);
		candidateDTO.setSecuredanswer(securedanswer);
		
	
		boolean register = candidateRegService.candregister(candidateDTO);

		if (register) {
			return new ModelAndView("candidatelogin.html");
		} else {
			return new ModelAndView("failure.html");
		}
}
	
	@PostMapping("/login1.do")
	public ModelAndView loginUser(@RequestParam String email, @RequestParam String password) {

		CandidateDTO candidateDTO = new CandidateDTO();

		candidateDTO.setEmail(email);
		candidateDTO.setPassword(password);
		

		boolean present = loginService.loginCandidate(candidateDTO);
		if (present) {
			return new ModelAndView("my-profile.jsp");
		} else {
			return new ModelAndView("failure.html");
		}
	}
	//company
	
	
	@PostMapping("/login2.do")
	public ModelAndView loginCompanyreg(@RequestParam String email, @RequestParam String password) {

		UserDTO userDTO = new UserDTO();

		userDTO.setEmail(email);
		userDTO.setPassword(password);

		boolean present = loginService.loginCompany(userDTO);
		if (present) {
			return new ModelAndView("companyportals.jsp");
		} else {
			return new ModelAndView("failure.html");
		}
	}
	
	@PostMapping("/adminlogin.do")
	public ModelAndView loginAdminreg(@RequestParam String email, @RequestParam String password) {

		AdminDTO adminDTO = new AdminDTO();

		adminDTO.setEmail(email);
		adminDTO.setPassword(password);

		boolean present = adminService.loginAdmin(adminDTO);
		if (present) {
			return new ModelAndView("AdminHome.html");
		} else {
			return new ModelAndView("failure.html");
		}
	}
	
	//security candidate

	@PostMapping("/security.do")
	public ModelAndView securequestion(@RequestParam String securedquestion, @RequestParam String securedanswer,@RequestParam String email,@RequestParam String password) {

		CandidateDTO candidateDTO = new CandidateDTO();

		candidateDTO.setSecuredquestion(securedquestion);
		candidateDTO.setSecuredanswer(securedanswer);
		candidateDTO.setEmail(email);
		candidateDTO.setPassword(password);

		boolean present = securityService.security(candidateDTO);
		if (present) {
			return new ModelAndView("candidatelogin.html");
		} else {
			return new ModelAndView("failure.html");
		}
	}
	
	//security company

		@PostMapping("/companysecurity.do")
		public ModelAndView secureanswer(@RequestParam String securedquestion, @RequestParam String securedanswer,@RequestParam String email,@RequestParam String password) {

			UserDTO userDTO = new UserDTO();

			userDTO.setSecuredquestion(securedquestion);
			userDTO.setSecuredanswer(securedanswer);
			userDTO.setEmail(email);
			userDTO.setPassword(password);

			boolean present = securityService.securityans(userDTO);
			if (present) {
				return new ModelAndView("companylogin.html");
			} else {
				return new ModelAndView("failure.html");
			}
		}
		
		
		
		
		
		@PostMapping("/hostjob.do")
		public ModelAndView job(@RequestParam int cmid,@RequestParam String name, @RequestParam String jobprofiLe, @RequestParam String location,
				@RequestParam int salary, @RequestParam int no_jobs, @RequestParam int percentage,
				@RequestParam int experience, @RequestParam int notice_period, @RequestParam String description) {

			HostJobDTO hostjobDTO = new HostJobDTO();
			
			hostjobDTO.setName(name);
			hostjobDTO.setJobprofile(jobprofiLe);
			hostjobDTO.setLocation(location);
			hostjobDTO.setSalary(salary);
			hostjobDTO.setNo_jobs(no_jobs);
			hostjobDTO.setPercentage(percentage);
			hostjobDTO.setExperience(experience);
			hostjobDTO.setNotice_period(notice_period);
			hostjobDTO.setDescription(description);
			hostjobDTO.setCmid(cmid);

			boolean host = hostjobService.jobregister(hostjobDTO);
			if (host) {
				return new ModelAndView("companyportals.jsp");
			} else {
				return new ModelAndView("failure.html");
			}
		}
		@PostMapping("/applyjob.do")
		public ModelAndView job(@RequestParam String companyname, @RequestParam String cname, @RequestParam String jobprofiLe, @RequestParam String location,
				@RequestParam int salary, @RequestParam int percentage,
				@RequestParam int experience) {

			ApplyJobDTO applyjob = new ApplyJobDTO();
			
			applyjob.setCompanyname(companyname);
			applyjob.setCname(cname);
			applyjob.setJobprofile(jobprofiLe);
			applyjob.setLocation(location);
			applyjob.setSalary(salary);
			applyjob.setPercentage(percentage);
			applyjob.setExperience(experience);
			

			boolean host = applyService.jobApply(applyjob);
			if (host) {
				return new ModelAndView("openings.jsp");
			} else {
				return new ModelAndView("failure.html");
			}
		}
	}
		
		
