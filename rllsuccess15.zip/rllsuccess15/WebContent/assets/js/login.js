$(document).ready(function()
{
$('form[id="form_val"]').validate({
rules:{
email:{
	required:true,
},
password: {
required: true,
},
type:
	{
		required:true
	}
},
messages:{
email:"Please provide the valid email",
password:{
required: "Please provide the valid password",
},
type:{
required: "Please provide the type"
}
},
submitHandler:function(form){
form.submit();
}
});
});