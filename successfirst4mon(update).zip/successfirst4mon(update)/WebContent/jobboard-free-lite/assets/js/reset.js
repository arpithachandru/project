$(document).ready(function(){

$('form[id="form_val2"]').validate({
rules:{
password: {
required: true,
	


},
confirmpassword:{
required: true,
equalTo: "#password"
}
},
messages:{
password:{
required: "Enter the password",
	

},
confirmpassword:{
required:"Enter confirm password",
equalTo:"Passwords does not match",
}
},
submitHandler:function(form){
form.submit();
}
});
});
