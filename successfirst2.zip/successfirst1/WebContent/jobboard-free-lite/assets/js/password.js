
$(document).ready(function(){

$('form[id="form_val1"]').validate({
rules:{
securedquestion: "required",
securedanswer:"required"
},

messages:{
securedquestion:"Please provide the valid name",


securedanswer: "Please provide the valid password",

},

submitHandler:function(form){
form.submit();
}
});
});