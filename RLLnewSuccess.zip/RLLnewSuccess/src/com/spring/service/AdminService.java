package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.AdminDAO;
import com.spring.dao.CandidateDAO;
import com.spring.dto.AdminDTO;
import com.spring.dto.CandidateDTO;
import com.spring.dto.UserDTO;

@Service
public class AdminService {
	@Autowired
	private AdminDAO adminDAO;

	public boolean adminregister(AdminDTO adminDTO) {
		Integer saveAdmin = adminDAO.saveAdmin(adminDTO);
		if (saveAdmin != null && saveAdmin > 0) {
			return true;
		} else {
			return false;
		}
	}
	public boolean loginAdmin(AdminDTO adminDTO) {
		String email = adminDTO.getEmail();
		String password = adminDTO.getPassword();
		AdminDTO loginAdmin = adminDAO.adminlog(email, password);
		if (loginAdmin != null) {
			return true;
		} else {
			return false;
		}
	}
}
