package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.CandidateDAO;
import com.spring.dao.LoginDAO;
import com.spring.dto.CandidateDTO;
import com.spring.dto.UserDTO;
@Service
public class LoginService {
	@Autowired
	private LoginDAO loginDAO;

	public boolean candidatelogin(CandidateDTO candidateDTO) {
		Integer saveCandidate = loginDAO.saveCandidate(candidateDTO);
		if (saveCandidate != null && saveCandidate > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	//candidate login
	public boolean loginCandidate(CandidateDTO candidateDTO) {
		String email = candidateDTO.getEmail();
		String password = candidateDTO.getPassword();
		CandidateDTO loginUser = loginDAO.loginUser(email, password);
		if (loginUser != null) {
			return true;
		} else {
			return false;
		}
	}
	
	// company
	
	public boolean loginCompany(UserDTO userDTO) {
		String email = userDTO.getEmail();
		String password = userDTO.getPassword();
		UserDTO loginUser = loginDAO.companylog(email, password);
		if (loginUser != null) {
			return true;
		} else {
			return false;
		}
	}
	
	
	
}
