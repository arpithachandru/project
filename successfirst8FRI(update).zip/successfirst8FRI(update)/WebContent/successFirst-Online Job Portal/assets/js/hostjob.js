$(document).ready(function(){

$('form[id="form_val1"]').validate({
rules:{

cname: "required",

},
	messages:{
cname:"Please enter company name",

},
submitHandler:function(form){
form.submit();
}
});
});