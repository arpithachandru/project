package com.spring.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "HOST_JOBS")
public class HostJobDTO implements Serializable {
	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "hid")
	private int hid;

	@Column(name = "cmid")
	private int cmid;

	@Column(name = "name")
	private String name;

	@Column(name = "jobprofile")
	private String jobprofile;

	@Column(name = "location")
	private String location;

	@Column(name = "salary")
	private int salary;

	@Column(name = "no_jobs")
	private int no_jobs;

	@Column(name = "percentage")
	private int percentage;

	@Column(name = "experience")
	private int experience;

	@Column(name = "notice_period")
	private int notice_period;

	@Column(name = "description")
	private String description;

	public HostJobDTO() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public int getHid() {
		return hid;
	}

	public void setHid(int hid) {
		this.hid = hid;
	}

	public int getCmid() {
		return cmid;
	}

	public void setCmid(int cmid) {
		this.cmid = cmid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJobprofile() {
		return jobprofile;
	}

	public void setJobprofile(String jobprofile) {
		this.jobprofile = jobprofile;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public int getNo_jobs() {
		return no_jobs;
	}

	public void setNo_jobs(int no_jobs) {
		this.no_jobs = no_jobs;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public int getNotice_period() {
		return notice_period;
	}

	public void setNotice_period(int notice_period) {
		this.notice_period = notice_period;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
