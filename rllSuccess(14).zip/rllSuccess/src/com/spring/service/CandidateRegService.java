package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.CandidateDAO;
import com.spring.dao.RegistrationDAO;
import com.spring.dto.CandidateDTO;
import com.spring.dto.UserDTO;
@Service
public class CandidateRegService {
	@Autowired
	private CandidateDAO candidateDAO;

	public boolean candregister(CandidateDTO candidateDTO) {
		Integer saveCandidate = candidateDAO.saveCandidate(candidateDTO);
		if (saveCandidate != null && saveCandidate > 0) {
			return true;
		} else {
			return false;
		}
	}
}
