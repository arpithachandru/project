
$(document).ready(function(){

$('form[id="form_val1"]').validate({
rules:{
securedquestion: "required",
securedanswer:"required"
},

messages:{
securedquestion:"Please select question",
securedanswer: "Please provide answer",

},

submitHandler:function(form){
form.submit();
}
});
});