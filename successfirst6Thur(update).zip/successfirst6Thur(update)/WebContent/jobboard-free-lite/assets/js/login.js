
$(document).ready(function(){

$('form[id="form_val"]').validate({
rules:{
name: "required",

password: {
required: true,
	

},
type:
	{
		required:true
	}
},
messages:{
name:"Please provide the valid name",

password:{
required: "Please provide the valid password",
		
	

},
type:{
required: "Please provide the type"
}
},
submitHandler:function(form){
form.submit();
}
});
});