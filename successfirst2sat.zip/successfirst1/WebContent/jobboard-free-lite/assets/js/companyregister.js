$(document).ready(function(){

$('form[id="form_val"]').validate({
rules:{

companyname: "required",
email:{
required:true,
email:true,
},
contact:{
required:true,
minlength:10,
maxlength:10,
},
description:{
required:true,
},
address:{
required:true,
}
,
password: {
required: true,
},
confirmpassword:{
required: true,
equalTo: "#password"
}
},
messages:{
companyname:"Enter company name",
email:{
required:"enter valid Email"
},
contact:{
required:"Please enter your contact no",
minlength:"contact no must be 10 digit",
maxlength:"contact no must be 10 digit"
},
description:{
required:"Please enter description",
},
address:{
required:"enter company address",
},
password:{
required: "Enter the valid password",
},
confirmpassword:{
required:"enter confirm password",
equalTo:"Passwords doesnot match",
}
},
submitHandler:function(form){
form.submit();
}
});
});